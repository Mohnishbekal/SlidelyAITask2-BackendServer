import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 3000;
const dbFilePath = path.resolve(__dirname, '../data/db.json');

app.use(express.json());

interface Submission {
    name: string;
    email: string;
    phone: string;
    github_link: string;
    stopwatch_time: string;
}

function readSubmissions(): Submission[] {
    if (fs.existsSync(dbFilePath)) {
        const data = fs.readFileSync(dbFilePath, 'utf8');
        return JSON.parse(data) as Submission[];
    } else {
        return [];
    }
}

app.post('/submit', (req: Request, res: Response) => {
    const { name, email, phone, github_link, stopwatch_time } = req.body;

    let submissions = readSubmissions();
    submissions.push({ name, email, phone, github_link, stopwatch_time });

    fs.writeFile(dbFilePath, JSON.stringify(submissions, null, 2), (err) => {
        if (err) {
            console.error('Error writing to db.json:', err);
            res.status(500).json({ message: 'Error saving submission' });
        } else {
            console.log('Successfully updated db.json');
            res.status(201).json({ message: 'Submission saved successfully' });
        }
    });
});

app.get('/read', (req: Request, res: Response) => {
    const { index } = req.query;
    const dataIndex = parseInt(index as string, 10);

    let submissions = readSubmissions();

    if (dataIndex >= 0 && dataIndex < submissions.length) {
        res.json(submissions[dataIndex]);
    } else {
        res.status(404).json({ message: 'Submission not found' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

